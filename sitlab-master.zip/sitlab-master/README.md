# sitlab
![alt text](https://github.com/lipika3/sitlab/blob/master/sincosgraph.png)
